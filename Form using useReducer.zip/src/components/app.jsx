import { useReducer, useRef } from "react";

export let App = () => {
  let reducerFun = (state, action) => {
    switch (action.type) {
      case "SET_DATA":
        
          return {
            fname: action.payload[0],
            lname: action.payload[1],
            age: Number(action.payload[2]),
            email: action.payload[3],
            phone: Number(action.payload[4]),
            password: action.payload[5],
        }

      default:
        return state;
    }
  };

  let fname = useRef();
  let lname = useRef();
  let age = useRef();
  let email = useRef();
  let phone = useRef();
  let password = useRef();
  //   let repassword = useRef();

  let [store, dispatch] = useReducer(reducerFun, {
    fname: "",
    lname: "",
    age: 0,
    phone: 0,
    email: "",
    password: "",
    // repassword: "",
  });

  // let load = [(fname.current.value),(lname.current.value),(age.current.value),(email.current.value),(phone.current.value),(password.current.value)]
  // console.log(fname.current.value);

  return (
    <div className="container">
      <h1>Registration Form</h1>

      <form action="#">
        <div className="mb-3">
          <label className="form-label" htmlFor="fname">
            First Name:{" "}
          </label>
          <input
            required
            className="form-control"
            id="fname"
            ref={fname}
            type="text"
          />
        </div>

        <div className="mb-3">
          <label className="form-label" htmlFor="lname">
            Last Name:{" "}
          </label>
          <input
            required
            className="form-control"
            id="lname"
            ref={lname}
            type="text"
          />
        </div>

        <div className="mb-3">
          <label className="form-label" htmlFor="age">
            Age:{" "}
          </label>
          <input
            required
            className="form-control"
            id="age"
            ref={age}
            type="number"
          />
        </div>

        <div className="mb-3">
          <label className="form-label" htmlFor="email">
            Email:{" "}
          </label>
          <input
            required
            className="form-control"
            id="email"
            ref={email}
            type="email"
          />
        </div>

        <div className="mb-3">
          <label className="form-label" htmlFor="phone">
            Phone:{" "}
          </label>
          <input
            required
            className="form-control"
            id="phone"
            ref={phone}
            type="number"
          />
        </div>

        <div className="mb-3">
          <label className="form-label" htmlFor="password">
            Password:{" "}
          </label>
          <input
            required
            className="form-control"
            id="password"
            ref={password}
            type="text"
          />
        </div>

        {/* <div className="mb-3">
          <label className="form-label" htmlFor="repassword">
            Re-Enter Password:{" "}
          </label>
          <input required
            className="form-control"
            id="repassword"
            ref={repassword}
            type="text"
          />
        </div> */}

        <button
          className="btn btn-primary"
          onClick={() => {
            if (
                fname.current.value !== "" &&
                lname.current.value !== "" &&
                age.current.value !== 0 &&
                email.current.value !== "" &&
                phone.current.value !== 0 &&
                password.current.value !== ""
              ) {
            dispatch({
              type: "SET_DATA",
              payload: [
                fname.current.value,
                lname.current.value,
                age.current.value,
                email.current.value,
                phone.current.value,
                password.current.value,
              ],
            });
        }
          }}
        >
          Register
        </button>
      </form>
      <br />
      <hr />
      <br />
      <div className="mb-3">
        <h2>First Name: {store.fname}</h2>
        <h2>Last Name: {store.lname}</h2>
        <h2>Age: {store.age}</h2>
        <h2>Email: {store.email}</h2>
        <h2>Phone: {store.phone}</h2>
        <h2>Password: {store.password}</h2>
      </div>
    </div>
  );
};
