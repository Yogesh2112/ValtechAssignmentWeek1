import React, { Component } from "react"; //default export
import Header from "./header";
import Mainsection1 from "./mainsection1";
import Mainsection2 from "./mainsection2";
import Footer from "./Footer";

class App extends Component{
    render(){
        return <div>
            <Header/>
            <main>
                <Mainsection1/>
                <Mainsection2/>
                <Footer/>
            </main>
        </div>
    }
}

export default App;