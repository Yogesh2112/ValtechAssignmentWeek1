import { Image, SafeAreaView, ScrollView, Text, View } from "react-native";
import Body from "./components/body";
import Header from "./components/header";

export default function App() {
  return <SafeAreaView style={{marginTop:10}}>
    <Header/>
    <ScrollView>
      <Body/>
    </ScrollView>
    </SafeAreaView>
}
