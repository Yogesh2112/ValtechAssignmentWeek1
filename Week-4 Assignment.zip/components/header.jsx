import { Image, SafeAreaView, ScrollView, Text, View } from "react-native";

let Header = () =>{
    return <SafeAreaView style={{display:"flex", flexDirection:"row", justifyContent:"space-between"}}>
    <View style={{margin:20, height:100}}>
    <Image style={{width:40, height:40}} source={require("../assets/images/default.jpg")}/>
    </View>
    <View style={{margin:20, height:100}}>
        <Image style={{width:40, height:40}} source={require("../assets/images/default_f.jpg")}/>
    </View>
    </SafeAreaView>
}

export default Header;
