const fs = require("node:fs");
const data = require("./data/data.json");
const herolist = require("./assets/herolist.json");
const city = require("./assets/city.json");
const poster = require("./assets/poster.json");
const { title } = require("node:process");

//loop through herolist to add all the heroes
for(let i = 0; i < herolist.length; i++){
    var hero = herolist[i];
    console.log(hero);
    
    //random cities for every hero
    var herocity = city[Math.round(Math.random() * city.length)];
    console.log(herocity);
    
    //random power level of every hero
    var heropower = Math.round(Math.random() * 10);
    console.log(heropower);
    
    //hero poster
    var heroposter = PosterForHero(hero);
    console.log(heroposter);
    
    //function to find correct poster for hero
    function PosterForHero(heroName) {
      for (let i = 0; i < herolist.length; i++) {
        if (herolist[i] === heroName) {
          return poster[i];
        }
      }
    }
    
    //javascript object for hero data
    var heroData = {
        Serial: (i+1), 
      title: hero,
      power: heropower,
      city: herocity,
      poster: heroposter,
    };
    
    //Push hero data to the avengers array
    data.avengers.push(heroData);
    console.log(data);
    
    //write the data in the file
    fs.writeFileSync("data/data.json", JSON.stringify(data), "utf-8", {flag : "a"});
}

