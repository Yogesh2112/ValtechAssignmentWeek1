const express = require("express");
const fs = require("node:fs");

var data = require("../hero.json");

var app = new express();
app.use(express.urlencoded({ extended: true }));

app.get("/", function (req, res) {
  res.render("form.pug", { avengers: data.avengers });
});

app.post("/", function (req, res) {
  var herodata = {
    title: req.body.hero,
    firstname: req.body.firstname,
    lastname: req.body.lastname,
    power: req.body.power,
    city: req.body.city,
  };

  // console.log(herodata);
  data.avengers.push(herodata);
  // console.log(data.avengers);
  fs.writeFileSync("./hero.json", JSON.stringify(data), "utf-8", { flag: "a" });
  res.redirect("/");
});

app.listen(5050, "localhost", (error) => {
  error
    ? console.log("Error: ", error)
    : console.log("Server started successfully");
});
